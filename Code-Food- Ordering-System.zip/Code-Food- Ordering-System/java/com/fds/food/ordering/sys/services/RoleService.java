package com.fds.food.ordering.sys.services;


import com.fds.food.ordering.sys.models.Role;

public interface RoleService {
    public Role getRole(String roleName);
}
