package com.fds.food.ordering.sys.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.oauth2.client.registration.ClientRegistration;
import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
import org.springframework.security.oauth2.client.registration.InMemoryClientRegistrationRepository;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableOAuth2Client;
import org.springframework.security.oauth2.core.AuthorizationGrantType;
import org.springframework.security.oauth2.core.oidc.IdTokenClaimNames;

import com.nimbusds.oauth2.sdk.auth.ClientAuthenticationMethod;

@Configuration
@EnableOAuth2Client
public class OAuth2Config {
	

	@Bean
	public ClientRegistrationRepository clientRegistrationRepository() {
	    return new InMemoryClientRegistrationRepository(clientRegistration());
	}

	private ClientRegistration clientRegistration() {
		return ClientRegistration.withRegistrationId("your-registration-id")
			    .clientId("your-client-id")
			    .clientSecret("your-client-secret")
			    .authorizationUri("your-authorization-uri")
			    .tokenUri("your-token-uri")
			    .redirectUriTemplate("your-redirect-uri")
			    .authorizationGrantType(AuthorizationGrantType.AUTHORIZATION_CODE)
			    .build();
	}

}
